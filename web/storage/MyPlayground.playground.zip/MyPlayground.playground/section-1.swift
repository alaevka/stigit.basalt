import UIKit
import CoreLocation
import XCPlayground
XCPSetExecutionShouldContinueIndefinitely(continueIndefinitely: true)


var str = "Hello, playground"


class GeoCordDelegate: NSObject, CLLocationManagerDelegate {
    
    func locationManager(manager: CLLocationManager!, didUpdateLocations locations: [AnyObject]!) {
        println("Updated Location")
        println(locationMgr.location.coordinate.latitude)
        println(locationMgr.location.coordinate.longitude)
    }
    
    
    func locationManager(manager: CLLocationManager!, didFailWithError error: NSError!) {
        println("Error while updating location " + error.localizedDescription)
    }
    
}


let locationMgr = CLLocationManager()

locationMgr.delegate = GeoCordDelegate()
locationMgr.desiredAccuracy = kCLLocationAccuracyBest
locationMgr.startUpdatingLocation()

